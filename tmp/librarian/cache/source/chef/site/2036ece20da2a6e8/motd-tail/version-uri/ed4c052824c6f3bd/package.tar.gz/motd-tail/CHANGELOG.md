motd-tail CHANGELOG
===================

v2.0.2 (2014-04-09)
-------------------
#7 - Fix wrong cookbook name in template source parameter


v2.0.0 (2014-03-18)
-------------------
Refactoring into a library cookbook to allow template replacement


v1.2.2 (2014-03-18)
-------------------
- [COOK-4434] - remove timestamp from template to prevent a change every Chef run


v1.2.0
------
- [COOK-2089] - Add the ability to add additional text to motd

v1.1.0
------
- [COOK-1387] - additional data for MOTD

v1.0.0
------
- Current public release.

