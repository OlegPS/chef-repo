sshd CHANGELOG
=====================

This file is used to list changes made in each version of the sshd cookbook.

1.0.0
-----

- [Chris Aumann] - Initial release of sshd
